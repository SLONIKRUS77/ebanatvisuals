package net.fabricmc.example;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Main mod initializer (common/server-safe entrypoint).
 * All client-only logic (rendering, GUI, keybinds) lives in
 * {@link net.fabricmc.example.EbanatVisualsClient}, which is registered
 * separately in fabric.mod.json under the "client" entrypoint so that
 * this class never touches client-only classes and the mod stays safe
 * to load in any environment check.
 */
public class EbanatVisualsMod implements ModInitializer {

    public static final String MOD_ID = "ebanatvisuals";
    public static final String MOD_NAME = "ebanatvisuals";

    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_NAME);

    @Override
    public void onInitialize() {
        LOGGER.info("[{}] Common initialization complete.", MOD_NAME);
    }
}