package net.fabricmc.example.gui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;

/**
 * Shared drawing helpers for the ClickGUI and InfoHUD: rounded rectangles
 * (background fills and outline borders), gradient strips for the hue
 * picker, and small geometric primitives. Everything is implemented on
 * top of {@link DrawContext} per the 1.21 requirement that all GUI/HUD
 * rendering go strictly through DrawContext rather than raw Tessellator
 * calls.
 */
public final class GuiRenderUtil {

    private GuiRenderUtil() {
    }

    /**
     * Draws a filled rectangle with rounded corners by compositing a
     * center fill, four edge fills, and four corner "pie" approximations
     * built from small filled triangles-as-rects at high enough
     * resolution to read as smooth curves at UI scale.
     */
    public static void drawRoundedRect(DrawContext context, float x, float y, float width, float height, int radius, int color) {
        radius = (int) Math.min(radius, Math.min(width, height) / 2f);
        if (radius <= 0) {
            context.fill((int) x, (int) y, (int) (x + width), (int) (y + height), color);
            return;
        }

        int ix = (int) x;
        int iy = (int) y;
        int iw = (int) width;
        int ih = (int) height;

        // Center cross fills.
        context.fill(ix + radius, iy, ix + iw - radius, iy + ih, color);
        context.fill(ix, iy + radius, ix + radius, iy + ih - radius, color);
        context.fill(ix + iw - radius, iy + radius, ix + iw, iy + ih - radius, color);

        // Rounded corners approximated via per-pixel-row scanlines using circle equation.
        drawCorner(context, ix + radius, iy + radius, radius, color, Corner.TOP_LEFT);
        drawCorner(context, ix + iw - radius, iy + radius, radius, color, Corner.TOP_RIGHT);
        drawCorner(context, ix + radius, iy + ih - radius, radius, color, Corner.BOTTOM_LEFT);
        drawCorner(context, ix + iw - radius, iy + ih - radius, radius, color, Corner.BOTTOM_RIGHT);
    }

    private enum Corner {
        TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT
    }

    private static void drawCorner(DrawContext context, int cx, int cy, int radius, int color, Corner corner) {
        for (int dy = 0; dy <= radius; dy++) {
            int dx = (int) Math.round(Math.sqrt((double) radius * radius - (double) dy * dy));

            int rowY;
            int fromX;
            int toX;

            switch (corner) {
                case TOP_LEFT -> {
                    rowY = cy - dy;
                    fromX = cx - dx;
                    toX = cx;
                }
                case TOP_RIGHT -> {
                    rowY = cy - dy;
                    fromX = cx;
                    toX = cx + dx;
                }
                case BOTTOM_LEFT -> {
                    rowY = cy + dy;
                    fromX = cx - dx;
                    toX = cx;
                }
                default -> {
                    rowY = cy + dy;
                    fromX = cx;
                    toX = cx + dx;
                }
            }

            context.fill(fromX, rowY, toX, rowY + 1, color);
        }
    }

    /**
     * Draws a rounded rectangle outline of the given stroke thickness by
     * drawing an outer rounded rect and then punching an inner rounded
     * rect of the background-less (transparent difference achieved by
     * drawing thin strips instead of a boolean subtract).
     */
    public static void drawRoundedRectBorder(DrawContext context, float x, float y, float width, float height, int radius, int color, float thickness) {
        int t = Math.max(1, Math.round(thickness));

        int ix = (int) x;
        int iy = (int) y;
        int iw = (int) width;
        int ih = (int) height;
        int r = (int) Math.min(radius, Math.min(width, height) / 2f);

        // Top and bottom edges.
        context.fill(ix + r, iy, ix + iw - r, iy + t, color);
        context.fill(ix + r, iy + ih - t, ix + iw - r, iy + ih, color);
        // Left and right edges.
        context.fill(ix, iy + r, ix + t, iy + ih - r, color);
        context.fill(ix + iw - t, iy + r, ix + iw, iy + ih - r, color);

        // Corner arcs (outline only) via thin ring approximation.
        drawCornerRing(context, ix + r, iy + r, r, t, color, Corner.TOP_LEFT);
        drawCornerRing(context, ix + iw - r, iy + r, r, t, color, Corner.TOP_RIGHT);
        drawCornerRing(context, ix + r, iy + ih - r, r, t, color, Corner.BOTTOM_LEFT);
        drawCornerRing(context, ix + iw - r, iy + ih - r, r, t, color, Corner.BOTTOM_RIGHT);
    }

    private static void drawCornerRing(DrawContext context, int cx, int cy, int radius, int thickness, int color, Corner corner) {
        for (int dy = 0; dy <= radius; dy++) {
            int outerDx = (int) Math.round(Math.sqrt((double) radius * radius - (double) dy * dy));
            int innerRadius = Math.max(0, radius - thickness);
            int innerDx = dy <= innerRadius ? (int) Math.round(Math.sqrt((double) innerRadius * innerRadius - (double) dy * dy)) : 0;

            int rowY;
            switch (corner) {
                case TOP_LEFT, TOP_RIGHT -> rowY = cy - dy;
                default -> rowY = cy + dy;
            }

            boolean left = corner == Corner.TOP_LEFT || corner == Corner.BOTTOM_LEFT;

            if (dy > radius - thickness) {
                // Near the flat cap: full thickness band.
                int fromX = left ? cx - outerDx : cx;
                int toX = left ? cx : cx + outerDx;
                context.fill(fromX, rowY, toX, rowY + 1, color);
            } else {
                int fromX = left ? cx - outerDx : cx + innerDx;
                int toX = left ? cx - innerDx : cx + outerDx;
                context.fill(fromX, rowY, toX, rowY + 1, color);
            }
        }
    }

    public static void drawHorizontalGradient(DrawContext context, int x, int y, int width, int height, int colorLeft, int colorRight) {
        context.fillGradient(x, y, x + width, y + height, colorLeft, colorRight);
    }

    public static boolean isMouseOver(double mouseX, double mouseY, float x, float y, float width, float height) {
        return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
    }
}