package net.fabricmc.example.gui;

/**
 * Small immutable-ish value holder describing the ClickGUI's main window
 * bounds, recomputed every time the screen is (re)initialized so it
 * stays responsive to the current scaled resolution. Kept as a separate
 * class (rather than fields directly on ClickGUI) so the responsive
 * sizing math is unit-testable/isolated and reusable if additional
 * floating panels are added later.
 */
public class GuiWindow {

    private float x;
    private float y;
    private float width;
    private float height;

    private static final float MIN_WIDTH = 220f;
    private static final float MAX_WIDTH = 420f;
    private static final float MIN_HEIGHT = 180f;
    private static final float MAX_HEIGHT = 520f;

    public GuiWindow() {
        this.x = 20f;
        this.y = 20f;
        this.width = MIN_WIDTH;
        this.height = MIN_HEIGHT;
    }

    /**
     * Recomputes window position and size as a proportion of the current
     * scaled screen dimensions, clamped to sane min/max bounds. This is
     * what makes the ClickGUI "responsive" across PC desktop resolutions
     * and small mobile/PojavLauncher screens: on a tiny screen the window
     * shrinks toward MIN_WIDTH/MIN_HEIGHT and centers itself; on a large
     * screen it grows toward MAX_WIDTH/MAX_HEIGHT instead of staying a
     * fixed pixel size that would look tiny or overflow.
     */
    public void recompute(int scaledScreenWidth, int scaledScreenHeight) {
        float proportionalWidth = scaledScreenWidth * 0.32f;
        float proportionalHeight = scaledScreenHeight * 0.55f;

        this.width = clamp(proportionalWidth, MIN_WIDTH, MAX_WIDTH);
        this.height = clamp(proportionalHeight, MIN_HEIGHT, MAX_HEIGHT);

        // Ensure window never exceeds screen bounds even at MIN sizes on
        // extremely small mobile viewports.
        this.width = Math.min(this.width, scaledScreenWidth - 16f);
        this.height = Math.min(this.height, scaledScreenHeight - 16f);

        this.x = (scaledScreenWidth - this.width) / 2f;
        this.y = (scaledScreenHeight - this.height) / 2f;
    }

    private float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public float getWidth() {
        return width;
    }

    public float getHeight() {
        return height;
    }

    public float getHeaderHeight() {
        return 26f;
    }

    public float getContentX() {
        return x + 10f;
    }

    public float getContentY() {
        return y + getHeaderHeight() + 8f;
    }

    public float getContentWidth() {
        return width - 20f;
    }
}