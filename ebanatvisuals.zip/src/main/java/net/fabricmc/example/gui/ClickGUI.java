package net.fabricmc.example.gui;

import net.fabricmc.example.config.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.List;

/**
 * The main ClickGUI screen. Responsive: recomputes its window bounds
 * from the current scaled screen size every time it's opened/resized.
 * Renders a dark, rounded-corner window with a header ("ebanatvisuals"),
 * a global accent color picker, and a scrollable list of module rows —
 * each with a toggle checkbox and a right-click-expandable settings
 * dropdown containing sliders, color pickers, enum dropdowns, and
 * boolean toggles.
 *
 * All rendering goes strictly through {@link DrawContext} per the 1.21
 * requirement. Mouse handling implements both left-click (toggle module
 * / interact with widgets) and right-click (expand/collapse a module's
 * settings dropdown) per the spec.
 */
public class ClickGUI extends Screen {

    private final ModuleManager moduleManager;
    private final GuiWindow window = new GuiWindow();

    private static final int ROW_HEIGHT = 26;
    private static final int ROW_SPACING = 6;

    private ColorSetting globalAccentPseudoSetting;
    private boolean globalAccentPickerOpen = false;

    private float scrollOffset = 0f;

    private Setting draggingColorChannel = null; // reused as a marker; real logic uses activeColorDrag fields
    private ColorSetting activeColorSetting = null;
    private int activeColorDragMode = 0; // 1 = hue/sat square, 2 = hue strip, 3 = alpha slider

    protected ClickGUI(ModuleManager moduleManager) {
        super(Text.literal("ebanatvisuals"));
        this.moduleManager = moduleManager;
    }

    @Override
    protected void init() {
        super.init();
        MinecraftClient client = MinecraftClient.getInstance();
        window.recompute(client.getWindow().getScaledWidth(), client.getWindow().getScaledHeight());
        layoutModules();
    }

    @Override
    public void resize(MinecraftClient client, int width, int height) {
        super.resize(client, width, height);
        window.recompute(client.getWindow().getScaledWidth(), client.getWindow().getScaledHeight());
        layoutModules();
    }

    private void layoutModules() {
        float x = window.getContentX();
        float y = window.getContentY() + 34f; // leave room for global accent row
        List<Module> modules = moduleManager.getModules();
        for (Module m : modules) {
            m.setGuiPosition(x, y);
            m.setGuiWidth(window.getContentWidth());
            y += ROW_HEIGHT + ROW_SPACING;
            if (m.isSettingsExpanded()) {
                y += m.getExpandedHeight();
            }
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Dim the game world slightly behind the GUI.
        context.fill(0, 0, this.width, this.height, 0x66000000);

        Theme theme = Theme.get();

        // Main window background + border.
        GuiRenderUtil.drawRoundedRect(context, window.getX(), window.getY(), window.getWidth(), window.getHeight(), theme.getCornerRadius(), theme.getWindowBackground());
        GuiRenderUtil.drawRoundedRectBorder(context, window.getX(), window.getY(), window.getWidth(), window.getHeight(), theme.getCornerRadius(), theme.getAccentARGB(220), 1.2f);

        // Header bar.
        GuiRenderUtil.drawRoundedRect(context, window.getX(), window.getY(), window.getWidth(), window.getHeaderHeight(), theme.getCornerRadius(), theme.getHeaderBackground());
        context.drawText(this.textRenderer, Text.literal("ebanatvisuals"), (int) (window.getX() + 10), (int) (window.getY() + 9), theme.getAccentARGB(255), false);

        // Global accent color row.
        renderGlobalAccentRow(context, mouseX, mouseY);

        // Scissor/clip content area so long module lists don't overflow the rounded window.
        int contentTop = (int) (window.getContentY() + 34f);
        int contentBottom = (int) (window.getY() + window.getHeight() - 8f);
        context.enableScissor((int) window.getContentX() - 2, contentTop - 2, (int) (window.getContentX() + window.getContentWidth()) + 2, contentBottom + 2);

        layoutModules();
        for (Module module : moduleManager.getModules()) {
            renderModuleRow(context, module, mouseX, mouseY);
        }

        context.disableScissor();

        super.render(context, mouseX, mouseY, delta);
    }

    private void renderGlobalAccentRow(DrawContext context, int mouseX, int mouseY) {
        Theme theme = Theme.get();
        float x = window.getContentX();
        float y = window.getContentY();
        float width = window.getContentWidth();

        GuiRenderUtil.drawRoundedRect(context, x, y, width, 26, 5, 0x33FFFFFF & theme.getWindowBackground() | 0x22000000);
        context.drawText(this.textRenderer, Text.literal("Global Accent Color"), (int) x + 6, (int) y + 9, 0xFFE0E0E0, false);

        float swatchSize = 16f;
        float swatchX = x + width - swatchSize - 8f;
        float swatchY = y + 5f;
        GuiRenderUtil.drawRoundedRect(context, swatchX, swatchY, swatchSize, swatchSize, 3, theme.getAccentARGB(255));
        GuiRenderUtil.drawRoundedRectBorder(context, swatchX, swatchY, swatchSize, swatchSize, 3, 0xFFFFFFFF, 1f);

        if (globalAccentPickerOpen) {
            renderGlobalAccentPicker(context, x, y + 30f, width, mouseX, mouseY);
        }
    }

    private void renderGlobalAccentPicker(DrawContext context, float x, float y, float width, int mouseX, int mouseY) {
        Theme theme = Theme.get();
        float pickerHeight = 90f;
        GuiRenderUtil.drawRoundedRect(context, x, y, width, pickerHeight, 5, 0xEE0A0A10);

        float squareSize = Math.min(width - 30f, 70f);
        float squareX = x + 6f;
        float squareY = y + 6f;

        float[] hsb = java.awt.Color.RGBtoHSB(theme.getAccentRed(), theme.getAccentGreen(), theme.getAccentBlue(), null);

        // Saturation/Brightness square (approximated with a gradient fill).
        int hueColor = java.awt.Color.HSBtoRGB(hsb[0], 1f, 1f) & 0xFFFFFF;
        context.fillGradient((int) squareX, (int) squareY, (int) (squareX + squareSize), (int) (squareY + squareSize), 0xFFFFFFFF, 0xFF000000 | hueColor);

        float knobX = squareX + hsb[1] * squareSize;
        float knobY = squareY + (1f - hsb[2]) * squareSize;
        context.fill((int) knobX - 2, (int) knobY - 2, (int) knobX + 2, (int) knobY + 2, 0xFFFFFFFF);

        // Hue strip.
        float hueX = squareX + squareSize + 8f;
        float hueY = squareY;
        float hueWidth = 14f;
        float hueHeight = squareSize;
        for (int i = 0; i < hueHeight; i++) {
            float h = i / hueHeight;
            int c = java.awt.Color.HSBtoRGB(h, 1f, 1f);
            context.fill((int) hueX, (int) (hueY + i), (int) (hueX + hueWidth), (int) (hueY + i + 1), 0xFF000000 | (c & 0xFFFFFF));
        }
        float hueKnobY = hueY + hsb[0] * hueHeight;
        context.fill((int) hueX - 2, (int) hueKnobY - 1, (int) (hueX + hueWidth + 2), (int) hueKnobY + 1, 0xFFFFFFFF);
    }

    private void renderModuleRow(DrawContext context, Module module, int mouseX, int mouseY) {
        Theme theme = Theme.get();
        float x = module.getGuiX();
        float y = module.getGuiY();
        float width = module.getGuiWidth();

        boolean hovered = GuiRenderUtil.isMouseOver(mouseX, mouseY, x, y, width, ROW_HEIGHT);
        int rowBg = hovered ? 0x40FFFFFF & 0x40FFFFFF | 0x30202028 : 0x28181820;
        GuiRenderUtil.drawRoundedRect(context, x, y, width, ROW_HEIGHT, 5, rowBg);

        int nameColor = module.isEnabled() ? 0xFFFFFFFF : 0xFFAAAAAA;
        context.drawText(this.textRenderer, Text.literal(module.getName()), (int) x + 8, (int) y + 9, nameColor, false);

        // Toggle indicator (right side circle/checkbox).
        float toggleSize = 14f;
        float toggleX = x + width - toggleSize - 8f;
        float toggleY = y + (ROW_HEIGHT - toggleSize) / 2f;
        int toggleColor = module.isEnabled() ? theme.getAccentARGB(255) : 0xFF3A3A42;
        GuiRenderUtil.drawRoundedRect(context, toggleX, toggleY, toggleSize, toggleSize, 4, toggleColor);
        GuiRenderUtil.drawRoundedRectBorder(context, toggleX, toggleY, toggleSize, toggleSize, 4, 0xFFFFFFFF, 1f);

        if (module.isSettingsExpanded()) {
            renderModuleSettings(context, module, x, y + ROW_HEIGHT + 2, width, mouseX, mouseY);
        }
    }

    private void renderModuleSettings(DrawContext context, Module module, float x, float y, float width, int mouseX, int mouseY) {
        int panelHeight = module.getExpandedHeight();
        GuiRenderUtil.drawRoundedRect(context, x, y, width, panelHeight, 5, 0xDD0E0E14);

        float cursorY = y + 6f;
        for (Setting setting : module.getSettings()) {
            cursorY = renderSetting(context, setting, x + 8f, cursorY, width - 16f, mouseX, mouseY);
        }
    }

    private float renderSetting(DrawContext context, Setting setting, float x, float y, float width, int mouseX, int mouseY) {
        Theme theme = Theme.get();

        if (setting instanceof SliderSetting slider) {
            context.drawText(this.textRenderer, Text.literal(slider.getName() + ": " + slider.getDisplayValue()), (int) x, (int) y, 0xFFE0E0E0, false);
            float trackY = y + 12f;
            float trackHeight = 6f;
            GuiRenderUtil.drawRoundedRect(context, x, trackY, width, trackHeight, 3, 0xFF2A2A32);
            float fillWidth = width * slider.getPercentage();
            GuiRenderUtil.drawRoundedRect(context, x, trackY, fillWidth, trackHeight, 3, theme.getAccentARGB(255));
            float knobX = x + fillWidth;
            context.fill((int) knobX - 2, (int) trackY - 2, (int) knobX + 2, (int) (trackY + trackHeight + 2), 0xFFFFFFFF);
            return y + slider.getHeight() + 6f;
        }

        if (setting instanceof ColorSetting color) {
            context.drawText(this.textRenderer, Text.literal(color.getName()), (int) x, (int) y + 4, 0xFFE0E0E0, false);
            float swatchSize = 14f;
            GuiRenderUtil.drawRoundedRect(context, x + width - swatchSize, y, swatchSize, swatchSize, 3, color.getARGB());
            GuiRenderUtil.drawRoundedRectBorder(context, x + width - swatchSize, y, swatchSize, swatchSize, 3, 0xFFFFFFFF, 1f);

            float cursor = y + 20f;
            if (color.isPickerOpen()) {
                float squareSize = 60f;
                float[] hsb = color.toHSB();
                int hueColor = java.awt.Color.HSBtoRGB(hsb[0], 1f, 1f) & 0xFFFFFF;
                context.fillGradient((int) x, (int) cursor, (int) (x + squareSize), (int) (cursor + squareSize), 0xFFFFFFFF, 0xFF000000 | hueColor);
                float knobX = x + hsb[1] * squareSize;
                float knobY = cursor + (1f - hsb[2]) * squareSize;
                context.fill((int) knobX - 2, (int) knobY - 2, (int) knobX + 2, (int) knobY + 2, 0xFFFFFFFF);

                float hueX = x + squareSize + 8f;
                for (int i = 0; i < squareSize; i++) {
                    float h = i / squareSize;
                    int c = java.awt.Color.HSBtoRGB(h, 1f, 1f);
                    context.fill((int) hueX, (int) (cursor + i), (int) (hueX + 12f), (int) (cursor + i + 1), 0xFF000000 | (c & 0xFFFFFF));
                }

                float alphaY = cursor + squareSize + 8f;
                GuiRenderUtil.drawRoundedRect(context, x, alphaY, width, 8f, 3, 0xFF2A2A32);
                float alphaFill = width * (color.getAlpha() / 255f);
                GuiRenderUtil.drawRoundedRect(context, x, alphaY, alphaFill, 8f, 3, theme.getAccentARGB(255));

                return y + color.getHeight() + 6f;
            }
            return y + color.getHeight() + 6f;
        }

        if (setting instanceof EnumSetting enumSetting) {
            context.drawText(this.textRenderer, Text.literal(enumSetting.getName() + ": " + enumSetting.getSelected()), (int) x, (int) y + 4, 0xFFE0E0E0, false);

            if (enumSetting.isDropdownOpen()) {
                float optionY = y + 20f;
                String[] options = enumSetting.getOptions();
                for (int i = 0; i < options.length; i++) {
                    boolean isSelected = i == enumSetting.getSelectedIndex();
                    int bg = isSelected ? theme.getAccentARGB(180) : 0x22FFFFFF;
                    GuiRenderUtil.drawRoundedRect(context, x, optionY, width, 16, 3, bg);
                    context.drawText(this.textRenderer, Text.literal(options[i]), (int) x + 4, (int) optionY + 4, 0xFFFFFFFF, false);
                    optionY += 18f;
                }
            }
            return y + enumSetting.getHeight() + 6f;
        }

        if (setting instanceof BooleanSetting bool) {
            context.drawText(this.textRenderer, Text.literal(bool.getName()), (int) x, (int) y + 5, 0xFFE0E0E0, false);
            float boxSize = 12f;
            float boxX = x + width - boxSize;
            int boxColor = bool.isEnabled() ? theme.getAccentARGB(255) : 0xFF3A3A42;
            GuiRenderUtil.drawRoundedRect(context, boxX, y, boxSize, boxSize, 3, boxColor);
            GuiRenderUtil.drawRoundedRectBorder(context, boxX, y, boxSize, boxSize, 3, 0xFFFFFFFF, 1f);
            return y + bool.getHeight() + 6f;
        }

        return y + setting.getHeight() + 6f;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        Theme theme = Theme.get();

        // Global accent swatch toggle.
        float accentRowX = window.getContentX();
        float accentRowY = window.getContentY();
        float accentRowWidth = window.getContentWidth();
        float swatchSize = 16f;
        float swatchX = accentRowX + accentRowWidth - swatchSize - 8f;
        float swatchY = accentRowY + 5f;
        if (button == 0 && GuiRenderUtil.isMouseOver(mouseX, mouseY, swatchX, swatchY, swatchSize, swatchSize)) {
            globalAccentPickerOpen = !globalAccentPickerOpen;
            return true;
        }

        if (globalAccentPickerOpen && button == 0) {
            float pickerX = accentRowX;
            float pickerY = accentRowY + 30f;
            float squareSize = Math.min(accentRowWidth - 30f, 70f);
            float squareX = pickerX + 6f;
            float squareY = pickerY + 6f;

            if (GuiRenderUtil.isMouseOver(mouseX, mouseY, squareX, squareY, squareSize, squareSize)) {
                float sat = (float) ((mouseX - squareX) / squareSize);
                float bri = 1f - (float) ((mouseY - squareY) / squareSize);
                sat = Math.max(0f, Math.min(1f, sat));
                bri = Math.max(0f, Math.min(1f, bri));
                float[] hsb = java.awt.Color.RGBtoHSB(theme.getAccentRed(), theme.getAccentGreen(), theme.getAccentBlue(), null);
                int rgb = java.awt.Color.HSBtoRGB(hsb[0], sat, bri);
                theme.setAccentColor((rgb >> 16) & 0xFF, (rgb >> 8) & 0xFF, rgb & 0xFF);
                return true;
            }

            float hueX = squareX + squareSize + 8f;
            float hueY = squareY;
            float hueWidth = 14f;
            float hueHeight = squareSize;
            if (GuiRenderUtil.isMouseOver(mouseX, mouseY, hueX, hueY, hueWidth, hueHeight)) {
                float h = (float) ((mouseY - hueY) / hueHeight);
                h = Math.max(0f, Math.min(1f, h));
                float[] hsb = java.awt.Color.RGBtoHSB(theme.getAccentRed(), theme.getAccentGreen(), theme.getAccentBlue(), null);
                int rgb = java.awt.Color.HSBtoRGB(h, hsb[1], hsb[2]);
                theme.setAccentColor((rgb >> 16) & 0xFF, (rgb >> 8) & 0xFF, rgb & 0xFF);
                return true;
            }
        }

        for (Module module : moduleManager.getModules()) {
            float x = module.getGuiX();
            float y = module.getGuiY();
            float width = module.getGuiWidth();

            if (GuiRenderUtil.isMouseOver(mouseX, mouseY, x, y, width, ROW_HEIGHT)) {
                if (button == 0) {
                    module.toggle();
                    return true;
                } else if (button == 1) {
                    module.toggleSettingsExpanded();
                    return true;
                }
            }

            if (module.isSettingsExpanded()) {
                if (handleSettingsClick(module, x + 8f, y + ROW_HEIGHT + 8f, width - 16f, mouseX, mouseY, button)) {
                    return true;
                }
            }
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    private boolean handleSettingsClick(Module module, float x, float y, float width, double mouseX, double mouseY, int button) {
        float cursorY = y;
        for (Setting setting : module.getSettings()) {
            float settingHeight = setting.getHeight();

            if (setting instanceof SliderSetting slider) {
                float trackY = cursorY + 12f;
                if (button == 0 && GuiRenderUtil.isMouseOver(mouseX, mouseY, x, trackY - 3f, width, 12f)) {
                    slider.setDragging(true);
                    float pct = (float) ((mouseX - x) / width);
                    slider.setPercentage(pct);
                    return true;
                }
            } else if (setting instanceof ColorSetting color) {
                float swatchSize = 14f;
                if (button == 0 && GuiRenderUtil.isMouseOver(mouseX, mouseY, x + width - swatchSize, cursorY, swatchSize, swatchSize)) {
                    color.togglePicker();
                    return true;
                }
                if (color.isPickerOpen()) {
                    float squareSize = 60f;
                    float pickerY = cursorY + 20f;
                    if (GuiRenderUtil.isMouseOver(mouseX, mouseY, x, pickerY, squareSize, squareSize)) {
                        float sat = (float) ((mouseX - x) / squareSize);
                        float bri = 1f - (float) ((mouseY - pickerY) / squareSize);
                        sat = Math.max(0f, Math.min(1f, sat));
                        bri = Math.max(0f, Math.min(1f, bri));
                        float[] hsb = color.toHSB();
                        color.fromHSB(hsb[0], sat, bri);
                        activeColorSetting = color;
                        activeColorDragMode = 1;
                        return true;
                    }
                    float hueX = x + squareSize + 8f;
                    if (GuiRenderUtil.isMouseOver(mouseX, mouseY, hueX, pickerY, 12f, squareSize)) {
                        float h = (float) ((mouseY - pickerY) / squareSize);
                        h = Math.max(0f, Math.min(1f, h));
                        float[] hsb = color.toHSB();
                        color.fromHSB(h, hsb[1], hsb[2]);
                        activeColorSetting = color;
                        activeColorDragMode = 2;
                        return true;
                    }
                    float alphaY = pickerY + squareSize + 8f;
                    if (GuiRenderUtil.isMouseOver(mouseX, mouseY, x, alphaY, width, 8f)) {
                        float pct = (float) ((mouseX - x) / width);
                        color.setAlpha(Math.round(Math.max(0f, Math.min(1f, pct)) * 255f));
                        activeColorSetting = color;
                        activeColorDragMode = 3;
                        return true;
                    }
                }
            } else if (setting instanceof EnumSetting enumSetting) {
                if (button == 0 && GuiRenderUtil.isMouseOver(mouseX, mouseY, x, cursorY, width, 20f)) {
                    enumSetting.toggleDropdown();
                    return true;
                }
                if (enumSetting.isDropdownOpen()) {
                    float optionY = cursorY + 20f;
                    String[] options = enumSetting.getOptions();
                    for (int i = 0; i < options.length; i++) {
                        if (GuiRenderUtil.isMouseOver(mouseX, mouseY, x, optionY, width, 16f)) {
                            enumSetting.setSelectedIndex(i);
                            enumSetting.setDropdownOpen(false);
                            return true;
                        }
                        optionY += 18f;
                    }
                }
            } else if (setting instanceof BooleanSetting bool) {
                if (button == 0 && GuiRenderUtil.isMouseOver(mouseX, mouseY, x, cursorY, width, 16f)) {
                    bool.toggle();
                    return true;
                }
            }

            cursorY += settingHeight + 6f;
        }
        return false;
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        for (Module module : moduleManager.getModules()) {
            if (!module.isSettingsExpanded()) {
                continue;
            }
            for (Setting setting : module.getSettings()) {
                if (setting instanceof SliderSetting slider && slider.isDragging()) {
                    float x = module.getGuiX() + 8f;
                    float width = module.getGuiWidth() - 16f;
                    float pct = (float) ((mouseX - x) / width);
                    slider.setPercentage(pct);
                    return true;
                }
            }
        }

        if (activeColorSetting != null && activeColorDragMode != 0) {
            handleColorDrag(mouseX, mouseY);
            return true;
        }

        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    private void handleColorDrag(double mouseX, double mouseY) {
        // Re-derive geometry is non-trivial without stored anchor points;
        // simplest robust approach is clamping using last-known picker
        // math relative to the owning module's current layout each drag tick.
        for (Module module : moduleManager.getModules()) {
            if (!module.isSettingsExpanded()) {
                continue;
            }
            float x = module.getGuiX() + 8f;
            float cursorY = module.getGuiY() + 26f + 8f;
            float width = module.getGuiWidth() - 16f;

            for (Setting setting : module.getSettings()) {
                if (setting == activeColorSetting && setting instanceof ColorSetting color && color.isPickerOpen()) {
                    float squareSize = 60f;
                    float pickerY = cursorY + 20f;

                    if (activeColorDragMode == 1) {
                        float sat = (float) ((mouseX - x) / squareSize);
                        float bri = 1f - (float) ((mouseY - pickerY) / squareSize);
                        sat = Math.max(0f, Math.min(1f, sat));
                        bri = Math.max(0f, Math.min(1f, bri));
                        float[] hsb = color.toHSB();
                        color.fromHSB(hsb[0], sat, bri);
                    } else if (activeColorDragMode == 2) {
                        float h = (float) ((mouseY - pickerY) / squareSize);
                        h = Math.max(0f, Math.min(1f, h));
                        float[] hsb = color.toHSB();
                        color.fromHSB(h, hsb[1], hsb[2]);
                    } else if (activeColorDragMode == 3) {
                        float alphaY = pickerY + squareSize + 8f;
                        float pct = (float) ((mouseX - x) / width);
                        color.setAlpha(Math.round(Math.max(0f, Math.min(1f, pct)) * 255f));
                    }
                    return;
                }
                cursorY += setting.getHeight() + 6f;
            }
        }
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        for (Module module : moduleManager.getModules()) {
            for (Setting setting : module.getSettings()) {
                if (setting instanceof SliderSetting slider) {
                    slider.setDragging(false);
                }
            }
        }
        activeColorSetting = null;
        activeColorDragMode = 0;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return true;
    }
}