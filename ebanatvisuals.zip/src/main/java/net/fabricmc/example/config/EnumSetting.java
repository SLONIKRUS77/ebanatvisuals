package net.fabricmc.example.config;

/**
 * A dropdown setting that cycles between a fixed list of string options
 * (e.g. the InfoHUD panel position: TOP_LEFT, TOP_CENTER, TOP_RIGHT,
 * BOTTOM_LEFT, BOTTOM_RIGHT). Rendered in the ClickGUI as a collapsed
 * row showing the current selection, which expands into a vertical list
 * of all options on click.
 */
public class EnumSetting extends Setting {

    private final String[] options;
    private int selectedIndex;
    private boolean dropdownOpen = false;

    public EnumSetting(String name, String[] options, int defaultIndex) {
        super(name);
        if (options == null || options.length == 0) {
            throw new IllegalArgumentException("EnumSetting '" + name + "' requires at least one option.");
        }
        this.options = options;
        this.selectedIndex = Math.max(0, Math.min(options.length - 1, defaultIndex));
    }

    public String[] getOptions() {
        return options;
    }

    public int getOptionCount() {
        return options.length;
    }

    public int getSelectedIndex() {
        return selectedIndex;
    }

    public String getSelected() {
        return options[selectedIndex];
    }

    public void setSelectedIndex(int index) {
        if (index >= 0 && index < options.length) {
            this.selectedIndex = index;
        }
    }

    public boolean isSelected(String option) {
        return options[selectedIndex].equals(option);
    }

    public void cycle() {
        selectedIndex = (selectedIndex + 1) % options.length;
    }

    public boolean isDropdownOpen() {
        return dropdownOpen;
    }

    public void setDropdownOpen(boolean open) {
        this.dropdownOpen = open;
    }

    public void toggleDropdown() {
        this.dropdownOpen = !this.dropdownOpen;
    }

    @Override
    public int getHeight() {
        return dropdownOpen ? 24 + (options.length * 18) : 24;
    }
}