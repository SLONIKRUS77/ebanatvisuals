package net.fabricmc.example.config;

import java.util.ArrayList;
import java.util.List;

/**
 * Base class for every toggleable feature module (World Color Shift,
 * Hit Particles, Belt Geometry, Info HUD). Holds the module's on/off
 * state, its list of Settings shown in the right-click dropdown panel,
 * and the layout state (position + expanded/collapsed) the ClickGUI
 * needs to draw and hit-test it.
 */
public abstract class Module {

    private final String name;
    private final String description;
    private final ModuleCategory category;
    private boolean enabled;

    private final List<Setting> settings = new ArrayList<>();

    // ClickGUI layout state - populated by ClickGUI's responsive layout pass.
    private float guiX;
    private float guiY;
    private float guiWidth = 150f;
    private boolean settingsExpanded = false;

    protected Module(String name, String description, ModuleCategory category, boolean defaultEnabled) {
        this.name = name;
        this.description = description;
        this.category = category;
        this.enabled = defaultEnabled;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public ModuleCategory getCategory() {
        return category;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        boolean wasEnabled = this.enabled;
        this.enabled = enabled;
        if (enabled && !wasEnabled) {
            onEnable();
        } else if (!enabled && wasEnabled) {
            onDisable();
        }
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    /** Called once when the module transitions from disabled to enabled. */
    protected void onEnable() {
    }

    /** Called once when the module transitions from enabled to disabled. */
    protected void onDisable() {
    }

    protected final void addSetting(Setting setting) {
        settings.add(setting);
    }

    public List<Setting> getSettings() {
        return settings;
    }

    public float getGuiX() {
        return guiX;
    }

    public float getGuiY() {
        return guiY;
    }

    public float getGuiWidth() {
        return guiWidth;
    }

    public void setGuiPosition(float x, float y) {
        this.guiX = x;
        this.guiY = y;
    }

    public void setGuiWidth(float width) {
        this.guiWidth = width;
    }

    public boolean isSettingsExpanded() {
        return settingsExpanded;
    }

    public void setSettingsExpanded(boolean settingsExpanded) {
        this.settingsExpanded = settingsExpanded;
    }

    public void toggleSettingsExpanded() {
        this.settingsExpanded = !this.settingsExpanded;
    }

    /**
     * Total pixel height of the module's dropdown panel when expanded,
     * derived by summing every setting's own reported height (which may
     * itself vary, e.g. an open color picker or open enum dropdown).
     */
    public int getExpandedHeight() {
        int total = 6;
        for (Setting s : settings) {
            total += s.getHeight() + 6;
        }
        return total;
    }

    public SliderSetting getSlider(String settingName) {
        for (Setting s : settings) {
            if (s instanceof SliderSetting && s.getName().equals(settingName)) {
                return (SliderSetting) s;
            }
        }
        throw new IllegalArgumentException("No slider setting named '" + settingName + "' in module " + name);
    }

    public ColorSetting getColor(String settingName) {
        for (Setting s : settings) {
            if (s instanceof ColorSetting && s.getName().equals(settingName)) {
                return (ColorSetting) s;
            }
        }
        throw new IllegalArgumentException("No color setting named '" + settingName + "' in module " + name);
    }

    public EnumSetting getEnum(String settingName) {
        for (Setting s : settings) {
            if (s instanceof EnumSetting && s.getName().equals(settingName)) {
                return (EnumSetting) s;
            }
        }
        throw new IllegalArgumentException("No enum setting named '" + settingName + "' in module " + name);
    }

    public BooleanSetting getBoolean(String settingName) {
        for (Setting s : settings) {
            if (s instanceof BooleanSetting && s.getName().equals(settingName)) {
                return (BooleanSetting) s;
            }
        }
        throw new IllegalArgumentException("No boolean setting named '" + settingName + "' in module " + name);
    }

    public enum ModuleCategory {
        VISUAL,
        HUD,
        COMBAT
    }
}