package net.fabricmc.example.config;

/**
 * An RGBA color setting rendered in the ClickGUI as a small color swatch
 * that expands, on click, into a full HSB picker (hue strip + saturation/
 * brightness square) plus an alpha/transparency slider. Internally the
 * color is stored as separate RGBA channels for direct use in ARGB packing
 * for DrawContext fill calls and OpenGL color buffers.
 */
public class ColorSetting extends Setting {

    private int red;
    private int green;
    private int blue;
    private int alpha;

    private boolean pickerOpen = false;

    public ColorSetting(String name, int red, int green, int blue, int alpha) {
        super(name);
        this.red = clamp(red);
        this.green = clamp(green);
        this.blue = clamp(blue);
        this.alpha = clamp(alpha);
    }

    public int getRed() {
        return red;
    }

    public int getGreen() {
        return green;
    }

    public int getBlue() {
        return blue;
    }

    public int getAlpha() {
        return alpha;
    }

    public void setRed(int red) {
        this.red = clamp(red);
    }

    public void setGreen(int green) {
        this.green = clamp(green);
    }

    public void setBlue(int blue) {
        this.blue = clamp(blue);
    }

    public void setAlpha(int alpha) {
        this.alpha = clamp(alpha);
    }

    public void setRGB(int r, int g, int b) {
        this.red = clamp(r);
        this.green = clamp(g);
        this.blue = clamp(b);
    }

    private int clamp(int v) {
        return Math.max(0, Math.min(255, v));
    }

    /** Packed 0xRRGGBB with no alpha channel. */
    public int getRGB() {
        return (red << 16) | (green << 8) | blue;
    }

    /** Packed 0xAARRGGBB using this setting's own alpha channel. */
    public int getARGB() {
        return (alpha << 24) | getRGB();
    }

    /** Packed 0xAARRGGBB using a caller-supplied alpha override (0-255). */
    public int getARGB(int alphaOverride) {
        return (clamp(alphaOverride) << 24) | getRGB();
    }

    /** Float array [r, g, b, a] each in 0..1, for GL/particle color buffers. */
    public float[] toFloatArray() {
        return new float[]{red / 255f, green / 255f, blue / 255f, alpha / 255f};
    }

    public boolean isPickerOpen() {
        return pickerOpen;
    }

    public void setPickerOpen(boolean pickerOpen) {
        this.pickerOpen = pickerOpen;
    }

    public void togglePicker() {
        this.pickerOpen = !this.pickerOpen;
    }

    public float[] toHSB() {
        return java.awt.Color.RGBtoHSB(red, green, blue, null);
    }

    public void fromHSB(float h, float s, float b) {
        int rgb = java.awt.Color.HSBtoRGB(h, s, b);
        this.red = (rgb >> 16) & 0xFF;
        this.green = (rgb >> 8) & 0xFF;
        this.blue = rgb & 0xFF;
    }

    @Override
    public int getHeight() {
        // Collapsed: just the swatch row. Expanded: swatch row + hue strip +
        // saturation/brightness square + alpha slider.
        return pickerOpen ? 132 : 24;
    }
}