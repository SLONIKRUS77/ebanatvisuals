package net.fabricmc.example.config;

/**
 * A simple on/off toggle setting, rendered in the ClickGUI as a small
 * checkbox/switch to the right of its label (e.g. "Rainbow Mode" on the
 * World Color Shift module).
 */
public class BooleanSetting extends Setting {

    private boolean value;

    public BooleanSetting(String name, boolean defaultValue) {
        super(name);
        this.value = defaultValue;
    }

    public boolean isEnabled() {
        return value;
    }

    public void setValue(boolean value) {
        this.value = value;
    }

    public void toggle() {
        this.value = !this.value;
    }

    @Override
    public int getHeight() {
        return 22;
    }
}