package net.fabricmc.example.config;

import net.fabricmc.example.modules.BeltGeometryModule;
import net.fabricmc.example.modules.HitParticlesModule;
import net.fabricmc.example.modules.InfoHUDModule;
import net.fabricmc.example.modules.WorldColorModule;

import java.util.ArrayList;
import java.util.List;

/**
 * Owns the master list of all registered Modules and provides typed
 * accessors so render engines don't need to search-by-name at render
 * time. Also assigns each module's initial ClickGUI grid position; the
 * ClickGUI itself re-flows this layout responsively whenever the window
 * is opened or the screen is resized.
 */
public class ModuleManager {

    private final List<Module> modules = new ArrayList<>();

    private WorldColorModule worldColorModule;
    private HitParticlesModule hitParticlesModule;
    private BeltGeometryModule beltGeometryModule;
    private InfoHUDModule infoHUDModule;

    public void registerDefaultModules() {
        worldColorModule = new WorldColorModule();
        hitParticlesModule = new HitParticlesModule();
        beltGeometryModule = new BeltGeometryModule();
        infoHUDModule = new InfoHUDModule();

        modules.add(worldColorModule);
        modules.add(hitParticlesModule);
        modules.add(beltGeometryModule);
        modules.add(infoHUDModule);

        // Fallback stacked layout; ClickGUI computes a responsive layout
        // based on actual scaled window size the moment it opens.
        float x = 16f;
        float y = 30f;
        for (Module m : modules) {
            m.setGuiPosition(x, y);
            y += 34f;
        }
    }

    public List<Module> getModules() {
        return modules;
    }

    public List<Module> getModulesByCategory(Module.ModuleCategory category) {
        List<Module> result = new ArrayList<>();
        for (Module m : modules) {
            if (m.getCategory() == category) {
                result.add(m);
            }
        }
        return result;
    }

    public WorldColorModule getWorldColorModule() {
        return worldColorModule;
    }

    public HitParticlesModule getHitParticlesModule() {
        return hitParticlesModule;
    }

    public BeltGeometryModule getBeltGeometryModule() {
        return beltGeometryModule;
    }

    public InfoHUDModule getInfoHUDModule() {
        return infoHUDModule;
    }

    public Module getModuleByName(String name) {
        for (Module m : modules) {
            if (m.getName().equalsIgnoreCase(name)) {
                return m;
            }
        }
        return null;
    }
}