package net.fabricmc.example.config;

/**
 * Global visual theme shared across the ClickGUI, the InfoHUD panel, and
 * every render engine. This is a singleton (not per-module) so that
 * changing the accent color picker in the ClickGUI's global settings
 * instantly propagates everywhere: GUI borders/accents, the rounded HUD
 * panel background/accent, and any module that opts to read the accent
 * color instead of its own override.
 */
public class Theme {

    private static final Theme INSTANCE = new Theme();

    private int accentRed = 120;
    private int accentGreen = 170;
    private int accentBlue = 255;

    private int backgroundAlpha = 180;
    private int cornerRadius = 8;

    private Theme() {
    }

    public static Theme get() {
        return INSTANCE;
    }

    public int getAccentRed() {
        return accentRed;
    }

    public int getAccentGreen() {
        return accentGreen;
    }

    public int getAccentBlue() {
        return accentBlue;
    }

    public void setAccentColor(int r, int g, int b) {
        this.accentRed = clamp(r);
        this.accentGreen = clamp(g);
        this.accentBlue = clamp(b);
    }

    private int clamp(int v) {
        return Math.max(0, Math.min(255, v));
    }

    /** Packed 0xRRGGBB accent color. */
    public int getAccentRGB() {
        return (accentRed << 16) | (accentGreen << 8) | accentBlue;
    }

    /** Packed 0xAARRGGBB accent color using a caller-supplied alpha. */
    public int getAccentARGB(int alpha) {
        return (clamp(alpha) << 24) | getAccentRGB();
    }

    public float[] getAccentFloatArray() {
        return new float[]{accentRed / 255f, accentGreen / 255f, accentBlue / 255f, 1f};
    }

    public int getBackgroundAlpha() {
        return backgroundAlpha;
    }

    public void setBackgroundAlpha(int alpha) {
        this.backgroundAlpha = clamp(alpha);
    }

    /** Dark translucent panel background, used by HUD panel and dropdowns. */
    public int getPanelBackground() {
        return (backgroundAlpha << 24) | 0x0A0A0F;
    }

    /** Slightly lighter translucent background, used by the main ClickGUI window. */
    public int getWindowBackground() {
        return (backgroundAlpha << 24) | 0x14141C;
    }

    /** Header bar background, a touch darker/more opaque than the window body. */
    public int getHeaderBackground() {
        int headerAlpha = Math.min(255, backgroundAlpha + 40);
        return (headerAlpha <<24) | 0x0C0C12;
    }

    public int getCornerRadius() {
        return cornerRadius;
    }

    public void setCornerRadius(int radius) {
        this.cornerRadius = Math.max(0, Math.min(16, radius));
    }
}