package net.fabricmc.example.config;

/**
 * Base class for every configurable value a Module can expose in its
 * ClickGUI right-click dropdown panel. Each concrete subclass reports
 * its own render height so the dropdown panel can lay out a variable
 * number of settings (sliders, color pickers, enum dropdowns, toggles)
 * without any fixed-size assumptions.
 */
public abstract class Setting {

    private final String name;

    protected Setting(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    /**
     * The height, in pixels, this setting occupies when rendered inside
     * its owning module's expanded settings dropdown. Some settings
     * (color pickers, enum dropdowns) change height when opened, so this
     * is queried live every frame rather than cached.
     */
    public abstract int getHeight();
}