package net.fabricmc.example.config;

/**
 * A draggable numeric setting rendered as a horizontal track + knob in
 * the ClickGUI. Supports both float and integer display modes (e.g.
 * "Particle Amount" should show whole numbers, "Pulse Speed" can show
 * decimals) via the isInteger flag, and an optional snap step.
 */
public class SliderSetting extends Setting {

    private final float min;
    private final float max;
    private float value;
    private final float step;
    private final boolean isInteger;
    private final String suffix;

    private boolean dragging = false;

    public SliderSetting(String name, float min, float max, float defaultValue, float step, boolean isInteger, String suffix) {
        super(name);
        this.min = min;
        this.max = max;
        this.value = clampToStep(Math.max(min, Math.min(max, defaultValue)), step);
        this.step = step;
        this.isInteger = isInteger;
        this.suffix = suffix == null ? "" : suffix;
    }

    public SliderSetting(String name, float min, float max, float defaultValue, float step, boolean isInteger) {
        this(name, min, max, defaultValue, step, isInteger, "");
    }

    private float clampToStep(float v, float step) {
        if (step <= 0f) {
            return v;
        }
        return Math.round(v / step) * step;
    }

    public float getMin() {
        return min;
    }

    public float getMax() {
        return max;
    }

    public float getValue() {
        return value;
    }

    public int getIntValue() {
        return Math.round(value);
    }

    public boolean isInteger() {
        return isInteger;
    }

    public String getSuffix() {
        return suffix;
    }

    public void setValue(float newValue) {
        float clamped = Math.max(min, Math.min(max, newValue));
        this.value = clampToStep(clamped, step);
    }

    /**
     * @return current value normalized to the 0..1 range for drawing the knob position.
     */
    public float getPercentage() {
        if (max == min) {
            return 0f;
        }
        return (value - min) / (max - min);
    }

    /**
     * Sets the value from a normalized 0..1 percentage, typically derived
     * from mouse X position relative to the slider track bounds.
     */
    public void setPercentage(float percentage) {
        percentage = Math.max(0f, Math.min(1f, percentage));
        setValue(min + percentage * (max - min));
    }

    public boolean isDragging() {
        return dragging;
    }

    public void setDragging(boolean dragging) {
        this.dragging = dragging;
    }

    public String getDisplayValue() {
        if (isInteger) {
            return getIntValue() + suffix;
        }
        return String.format("%.2f", value) + suffix;
    }

    @Override
    public int getHeight() {
        return 28;
    }
}