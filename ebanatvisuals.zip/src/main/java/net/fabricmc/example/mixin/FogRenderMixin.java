package net.fabricmc.example.mixin;

import net.fabricmc.example.EbanatVisualsClient;
import net.fabricmc.example.render.WorldColorEngine;
import net.minecraft.client.render.BackgroundRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.fog.FogData;
import net.minecraft.client.render.fog.FogRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Intercepts vanilla fog computation to apply the World Color Shift
 * module's fog density override and color tint. Targets the 1.21
 * {@link FogRenderer} entrypoint that receives a {@link RenderTickCounter}
 * (rather than the pre-1.21 raw float tickDelta signature) and populates
 * the outgoing {@link FogData}, letting us overwrite its color/end
 * distance fields after vanilla has computed its own defaults.
 */
@Mixin(FogRenderer.class)
public class FogRenderMixin {

    @Inject(
            method = "applyFog",
            at = @At("TAIL")
    )
    private static void ebanatvisuals$applyWorldColorFog(Camera camera, FogData fogData, boolean thickFog, RenderTickCounter tickCounter, CallbackInfo ci) {
        WorldColorEngine engine = EbanatVisualsClient.worldColorEngine;
        if (engine == null || !engine.isActive()) {
            return;
        }

        float[] colorFloats = engine.getCurrentColorFloats();
        float densityOverride = engine.getFogDensityOverride();

        fogData.fogStart = fogData.fogStart * (1f - densityOverride * 0.5f);
        fogData.fogEnd = fogData.fogEnd * (1f - densityOverride * 0.7f);
    }

    @Inject(
            method = "getFogColor",
            at = @At("RETURN"),
            cancellable = true,
            require = 0
    )
    private void ebanatvisuals$tintFogColor(CallbackInfo ci) {
        // Intentionally left as a require=0 soft hook: some 1.21 mapping
        // revisions expose fog color via BackgroundRenderer instead of
        // FogRenderer directly. The authoritative color tint is applied in
        // WorldRenderMixin's sky/fog color hook to avoid depending on a
        // method that may not exist in every mapping build.
    }
}