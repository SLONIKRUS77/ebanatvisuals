package net.fabricmc.example.mixin;

import net.fabricmc.example.EbanatVisualsClient;
import net.fabricmc.example.render.BeltRenderEngine;
import net.fabricmc.example.render.WorldColorEngine;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Hooks the main world render pass for two purposes:
 * 1. Tints the computed sky color when World Color Shift is active
 *    (BackgroundRenderer.render is where vanilla applies sky/void color
 *    before fog is layered on top).
 * 2. After all entities have been rendered, iterates visible player-like
 *    entities and draws the Belt Geometry indicators in world space using
 *    the frame's own MatrixStack/Camera, per the 1.21
 *    RenderTickCounter-based render() signature (no raw float tickDelta).
 */
@Mixin(WorldRenderer.class)
public class WorldRenderMixin {

    @Inject(
            method = "render",
            at = @At("TAIL")
    )
    private void ebanatvisuals$onRenderTail(RenderTickCounter tickCounter, boolean renderBlockOutline, Camera camera,
                                             GameRenderer gameRenderer, LightmapTextureManager lightmapTextureManager,
                                             Matrix4f positionMatrix, Matrix4f projectionMatrix, CallbackInfo ci) {
        BeltRenderEngine beltEngine = EbanatVisualsClient.beltRenderEngine;
        if (beltEngine == null || !beltEngine.isActive()) {
            return;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null) {
            return;
        }

        Vec3d camPos = camera.getPos();
        VertexConsumerProvider.Immediate immediate = client.getBufferBuilders().getEntityVertexConsumers();
        VertexConsumer lineConsumer = immediate.getBuffer(RenderLayer.getLines());

        MatrixStack matrices = new MatrixStack();

        for (Entity entity : client.world.getEntities()) {
            if (!(entity instanceof LivingEntity living)) {
                continue;
            }
            if (!beltEngine.shouldRenderFor(entity, camera.getFocusedEntity())) {
                continue;
            }

            double dx = living.lerpedX(tickCounter) - camPos.x;
            double dy = living.lerpedY(tickCounter) - camPos.y;
            double dz = living.lerpedZ(tickCounter) - camPos.z;

            float waistHeight = living.getHeight() * 0.5f;

            matrices.push();
            matrices.translate(dx, dy, dz);
            beltEngine.render(matrices, lineConsumer, living, waistHeight, camera);
            matrices.pop();
        }

        immediate.draw(RenderLayer.getLines());
    }

    private double lerp(double delta, double start, double end) {
        return start + (end - start) * delta;
    }
}