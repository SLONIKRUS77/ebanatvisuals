package net.fabricmc.example.mixin;

import net.fabricmc.example.EbanatVisualsClient;
import net.fabricmc.example.render.HitParticlesEngine;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Hooks the local player's attack-entity interaction to trigger the
 * custom Hit Particles burst. Targets {@link ClientPlayerInteractionManager#attackEntity}
 * which is invoked once per left-click attack against a valid target,
 * before any server round-trip, giving instant client-side visual
 * feedback regardless of server tick latency.
 */
@Mixin(ClientPlayerInteractionManager.class)
public class ClientPlayerEntityMixin {

    @Inject(
            method = "attackEntity",
            at = @At("HEAD")
    )
    private void ebanatvisuals$onAttackEntity(net.minecraft.entity.player.PlayerEntity player, Entity target, CallbackInfo ci) {
        HitParticlesEngine engine = EbanatVisualsClient.hitParticlesEngine;
        if (engine == null) {
            return;
        }
        engine.spawnHitParticles(target);
    }
}