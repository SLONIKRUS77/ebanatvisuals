package net.fabricmc.example.mixin;

import net.fabricmc.example.EbanatVisualsClient;
import net.fabricmc.example.render.BeltRenderEngine;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Secondary hook point for the Belt Geometry indicators, attached
 * directly to each living entity's own render call rather than the
 * whole-world pass. This mixin exists as a per-entity fallback/anchor
 * point using the current 1.21 {@link LivingEntityRenderState}-based
 * render signature (post-entity-render-state refactor), ensuring belt
 * geometry correctly follows each entity's own interpolated pose matrix
 * stack rather than only a manually-recomputed camera-relative offset.
 * The primary draw call is issued from {@link WorldRenderMixin} for
 * batched line-layer submission; this mixin is intentionally a light
 * no-op hook reserved for renderer-level extension (e.g. future per-limb
 * attachment) and is kept safe/inert to avoid double-rendering the
 * geometry.
 */
@Mixin(LivingEntityRenderer.class)
public class LivingEntityRendererMixin<T extends LivingEntity, S extends LivingEntityRenderState> {

    @Inject(
            method = "render",
            at = @At("TAIL")
    )
    private void ebanatvisuals$onRenderStateTail(S state, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, CallbackInfo ci) {
        BeltRenderEngine beltEngine = EbanatVisualsClient.beltRenderEngine;
        if (beltEngine == null || !beltEngine.isActive()) {
            return;
        }
        // Intentional no-op: batched belt geometry rendering is handled
        // centrally in WorldRenderMixin against the world's line RenderLayer
        // to avoid submitting duplicate draw calls per entity renderer
        // instance. This hook is retained as the documented extension
        // point for future per-entity-state customization (e.g. reading
        // state.age or state.pose to vary belt scale per entity).
    }
}