package net.fabricmc.example.modules;

import net.fabricmc.example.config.ColorSetting;
import net.fabricmc.example.config.Module;
import net.fabricmc.example.config.SliderSetting;

/**
 * "Hit Particles Customization" module. Holds the visual configuration
 * for the custom particle burst spawned when the local player attacks
 * an entity. The actual particle spawning happens in
 * {@link net.fabricmc.example.render.HitParticlesEngine}, triggered from
 * the attack-entity mixin hook.
 */
public class HitParticlesModule extends Module {

    public static final String SETTING_COLOR = "Particle Color";
    public static final String SETTING_AMOUNT = "Particle Amount";
    public static final String SETTING_SPREAD_SPEED = "Spread Speed";

    public HitParticlesModule() {
        super(
                "Hit Particles",
                "Spawns custom colored particles when you attack an entity.",
                ModuleCategory.COMBAT,
                false
        );

        addSetting(new ColorSetting(SETTING_COLOR, 255, 60, 60, 255));
        addSetting(new SliderSetting(SETTING_AMOUNT, 1f, 50f, 12f, 1f, true, ""));
        addSetting(new SliderSetting(SETTING_SPREAD_SPEED, 0.01f, 2f, 0.25f, 0.01f, false, ""));
    }

    public ColorSetting colorSetting() {
        return getColor(SETTING_COLOR);
    }

    public SliderSetting amountSetting() {
        return getSlider(SETTING_AMOUNT);
    }

    public SliderSetting spreadSpeedSetting() {
        return getSlider(SETTING_SPREAD_SPEED);
    }
}