package net.fabricmc.example.modules;

import net.fabricmc.example.config.ColorSetting;
import net.fabricmc.example.config.Module;
import net.fabricmc.example.config.SliderSetting;

/**
 * "Belt Geometry Indicators" module. Configures the 3D geometric shapes
 * (two side circles + one center oval) rendered at waist height over
 * every player model. Actual world-space rendering happens in
 * {@link net.fabricmc.example.render.BeltRenderEngine}, hooked from
 * {@link net.fabricmc.example.mixin.WorldRenderMixin}.
 */
public class BeltGeometryModule extends Module {

    public static final String SETTING_COLOR = "Shape Color";
    public static final String SETTING_ALPHA = "Alpha";
    public static final String SETTING_SCALE = "Scale";

    public BeltGeometryModule() {
        super(
                "Belt Geometry",
                "Renders 3D geometric belt indicators (two circles + center oval) at waist level on player models.",
                ModuleCategory.VISUAL,
                false
        );

        addSetting(new ColorSetting(SETTING_COLOR, 255, 215, 0, 200));
        addSetting(new SliderSetting(SETTING_ALPHA, 0f, 255f, 180f, 1f, true, ""));
        addSetting(new SliderSetting(SETTING_SCALE, 0.2f, 2.5f, 1f, 0.05f, false, "x"));
    }

    public ColorSetting colorSetting() {
        return getColor(SETTING_COLOR);
    }

    public SliderSetting alphaSetting() {
        return getSlider(SETTING_ALPHA);
    }

    public SliderSetting scaleSetting() {
        return getSlider(SETTING_SCALE);
    }
}