package net.fabricmc.example.modules;

import net.fabricmc.example.config.EnumSetting;
import net.fabricmc.example.config.Module;
import net.fabricmc.example.config.SliderSetting;

/**
 * "Info HUD" module. Configures the rounded semi-transparent panel that
 * displays player username, server IP / "Singleplayer", ping, and online
 * player count. Position on screen is chosen via an EnumSetting; actual
 * drawing happens in {@link net.fabricmc.example.render.InfoHUD}.
 */
public class InfoHUDModule extends Module {

    public static final String SETTING_POSITION = "Position";
    public static final String SETTING_SCALE = "Scale";
    public static final String SETTING_PANEL_ALPHA = "Panel Alpha";

    public static final String POS_TOP_LEFT = "TOP_LEFT";
    public static final String POS_TOP_CENTER = "TOP_CENTER";
    public static final String POS_TOP_RIGHT = "TOP_RIGHT";
    public static final String POS_BOTTOM_LEFT = "BOTTOM_LEFT";
    public static final String POS_BOTTOM_RIGHT = "BOTTOM_RIGHT";

    public InfoHUDModule() {
        super(
                "Info HUD",
                "A rounded panel showing username, server, ping, and player count.",
                ModuleCategory.HUD,
                true
        );

        addSetting(new EnumSetting(
                SETTING_POSITION,
                new String[]{POS_TOP_LEFT, POS_TOP_CENTER, POS_TOP_RIGHT, POS_BOTTOM_LEFT, POS_BOTTOM_RIGHT},
                2
        ));
        addSetting(new SliderSetting(SETTING_SCALE, 0.5f, 2f, 1f, 0.05f, false, "x"));
        addSetting(new SliderSetting(SETTING_PANEL_ALPHA, 0f, 255f, 180f, 1f, true, ""));
    }

    public EnumSetting positionSetting() {
        return getEnum(SETTING_POSITION);
    }

    public SliderSetting scaleSetting() {
        return getSlider(SETTING_SCALE);
    }

    public SliderSetting panelAlphaSetting() {
        return getSlider(SETTING_PANEL_ALPHA);
    }
}