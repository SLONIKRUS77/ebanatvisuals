package net.fabricmc.example.modules;

import net.fabricmc.example.config.BooleanSetting;
import net.fabricmc.example.config.ColorSetting;
import net.fabricmc.example.config.Module;
import net.fabricmc.example.config.SliderSetting;

/**
 * "World Color Shift / Pulse" module. Purely a data holder for its
 * settings — the actual color math (pulsing, rainbow cycling, fog
 * density application) lives in {@link net.fabricmc.example.render.WorldColorEngine},
 * which reads these settings every tick/frame.
 */
public class WorldColorModule extends Module {

    public static final String SETTING_COLOR = "Color";
    public static final String SETTING_PULSE_SPEED = "Pulse Speed";
    public static final String SETTING_RAINBOW_MODE = "Rainbow Mode";
    public static final String SETTING_FOG_DENSITY = "Fog Density";

    public WorldColorModule() {
        super(
                "World Color Shift",
                "Dynamically alters world, fog, and sky colors with a pulsing or rainbow effect.",
                ModuleCategory.VISUAL,
                false
        );

        addSetting(new ColorSetting(SETTING_COLOR, 120, 170, 255, 255));
        addSetting(new SliderSetting(SETTING_PULSE_SPEED, 0.1f, 10f, 2f, 0.1f, false, "x"));
        addSetting(new BooleanSetting(SETTING_RAINBOW_MODE, false));
        addSetting(new SliderSetting(SETTING_FOG_DENSITY, 0f, 1f, 0.3f, 0.01f, false, ""));
    }

    public ColorSetting colorSetting() {
        return getColor(SETTING_COLOR);
    }

    public SliderSetting pulseSpeedSetting() {
        return getSlider(SETTING_PULSE_SPEED);
    }

    public BooleanSetting rainbowModeSetting() {
        return getBoolean(SETTING_RAINBOW_MODE);
    }

    public SliderSetting fogDensitySetting() {
        return getSlider(SETTING_FOG_DENSITY);
    }
}