package net.fabricmc.example.render;

import net.fabricmc.example.config.ColorSetting;
import net.fabricmc.example.config.ModuleManager;
import net.fabricmc.example.modules.WorldColorModule;

/**
 * Drives the "World Color Shift / Pulse" effect. Every client tick this
 * advances an internal phase used for both the pulse (sine-wave lerp
 * between black and the configured color) and rainbow (full hue cycle)
 * modes. {@link net.fabricmc.example.mixin.FogRenderMixin} and
 * {@link net.fabricmc.example.mixin.WorldRenderMixin} read
 * {@link #getCurrentColor()} / {@link #getFogDensityOverride()} every
 * frame to tint fog and sky rendering.
 */
public class WorldColorEngine {

    private final ModuleManager moduleManager;

    private float phase = 0f;
    private float hue = 0f;

    private int currentRed = 0;
    private int currentGreen = 0;
    private int currentBlue = 0;

    public WorldColorEngine(ModuleManager moduleManager) {
        this.moduleManager = moduleManager;
    }

    /**
     * Called once per client tick from {@link net.fabricmc.example.EbanatVisualsClient}.
     * Advances the pulse/rainbow phase independent of render framerate so
     * the effect speed stays consistent regardless of FPS.
     */
    public void tick() {
        WorldColorModule module = moduleManager.getWorldColorModule();
        if (!module.isEnabled()) {
            return;
        }

        float pulseSpeed = module.pulseSpeedSetting().getValue();
        phase += 0.05f * pulseSpeed;
        if (phase > Math.PI * 2) {
            phase -= (float) (Math.PI * 2);
        }

        if (module.rainbowModeSetting().isEnabled()) {
            hue += 0.004f * pulseSpeed;
            if (hue > 1f) {
                hue -= 1f;
            }
            int rgb = java.awt.Color.HSBtoRGB(hue, 0.85f, 1f);
            currentRed = (rgb >> 16) & 0xFF;
            currentGreen = (rgb >> 8) & 0xFF;
            currentBlue = rgb & 0xFF;
        } else {
            ColorSetting color = module.colorSetting();
            // Sine pulse between 35% and 100% brightness of the configured color.
            float brightness = 0.35f + 0.65f * ((float) (Math.sin(phase) + 1.0) / 2f);
            currentRed = Math.round(color.getRed() * brightness);
            currentGreen = Math.round(color.getGreen() * brightness);
            currentBlue = Math.round(color.getBlue() * brightness);
        }
    }

    /**
     * @return true if the module is enabled and mixins should apply the override.
     */
    public boolean isActive() {
        return moduleManager.getWorldColorModule().isEnabled();
    }

    /** Current computed sky/fog tint as float[]{r, g, b} each in 0..1, for fog color mixins. */
    public float[] getCurrentColorFloats() {
        return new float[]{currentRed / 255f, currentGreen / 255f, currentBlue / 255f};
    }

    public int getCurrentColorRGB() {
        return (currentRed << 16) | (currentGreen << 8) | currentBlue;
    }

    /** @return the configured fog density (0..1), used by FogRenderMixin to override fog end distance. */
    public float getFogDensityOverride() {
        return moduleManager.getWorldColorModule().fogDensitySetting().getValue();
    }
}