package net.fabricmc.example.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.example.config.ColorSetting;
import net.fabricmc.example.config.ModuleManager;
import net.fabricmc.example.modules.BeltGeometryModule;
import net.minecraft.client.render.BufferBuilderStorage;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.util.List;

/**
 * Renders the "Belt Geometry Indicators": two circles on the left/right
 * sides of a player's waist plus one larger oval centered on the belt
 * line, all drawn as world-space line loops in the entity's local
 * coordinate frame. Invoked once per frame per visible player entity
 * from {@link net.fabricmc.example.mixin.WorldRenderMixin} /
 * {@link net.fabricmc.example.mixin.LivingEntityRendererMixin}.
 */
public class BeltRenderEngine {

    private static final int CIRCLE_SEGMENTS = 32;
    private static final float BASE_RADIUS = 0.28f;
    private static final float SIDE_OFFSET = 0.32f;

    private final ModuleManager moduleManager;

    public BeltRenderEngine(ModuleManager moduleManager) {
        this.moduleManager = moduleManager;
    }

    public boolean isActive() {
        return moduleManager.getBeltGeometryModule().isEnabled();
    }

    /**
     * Draws the belt geometry for a single living entity. Called with a
     * MatrixStack already translated to the entity's render-relative
     * world position (camera-relative), per 1.21 world rendering
     * convention. This method pushes its own local transform on top.
     */
    public void render(MatrixStack matrices, VertexConsumer lineConsumer, LivingEntity entity, float waistHeight, Camera camera) {
        BeltGeometryModule module = moduleManager.getBeltGeometryModule();
        if (!module.isEnabled()) {
            return;
        }

        ColorSetting colorSetting = module.colorSetting();
        int alpha = module.alphaSetting().getIntValue();
        float scale = module.scaleSetting().getValue();

        float r = colorSetting.getRed() / 255f;
        float g = colorSetting.getGreen() / 255f;
        float b = colorSetting.getBlue() / 255f;
        float a = alpha / 255f;

        matrices.push();
        matrices.translate(0, waistHeight, 0);

        Matrix4f matrix = matrices.peek().getPositionMatrix();

        // Center oval (wider on X/Z than the side circles, flattened ellipse).
        drawEllipseLoop(matrix, lineConsumer, 0f, 0f, BASE_RADIUS * scale * 1.4f, BASE_RADIUS * scale * 0.85f, r, g, b, a);

        // Left side circle.
        drawEllipseLoop(matrix, lineConsumer, -SIDE_OFFSET * scale, 0f, BASE_RADIUS * scale * 0.6f, BASE_RADIUS * scale * 0.6f, r, g, b, a);

        // Right side circle.
        drawEllipseLoop(matrix, lineConsumer, SIDE_OFFSET * scale, 0f, BASE_RADIUS * scale * 0.6f, BASE_RADIUS * scale * 0.6f, r, g, b, a);

        matrices.pop();
    }

    /**
     * Emits a closed ring of line-strip vertices forming an ellipse in
     * the local XZ plane (horizontal, belt-height ring) centered at
     * (centerX, 0, centerZOffset=0) relative to the current matrix.
     */
    private void drawEllipseLoop(Matrix4f matrix, VertexConsumer consumer, float centerX, float centerZ,
                                  float radiusX, float radiusZ, float r, float g, float b, float a) {
        float prevX = centerX + radiusX;
        float prevZ = centerZ;

        for (int i = 1; i <= CIRCLE_SEGMENTS; i++) {
            float angle = (float) (i * (Math.PI * 2) / CIRCLE_SEGMENTS);
            float x = centerX + MathHelper.cos(angle) * radiusX;
            float z = centerZ + MathHelper.sin(angle) * radiusZ;

            consumer.vertex(matrix, prevX, 0f, prevZ).color(r, g, b, a).normal(0f, 1f, 0f);
            consumer.vertex(matrix, x, 0f, z).color(r, g, b, a).normal(0f, 1f, 0f);

            prevX = x;
            prevZ = z;
        }
    }

    /**
     * @return true if this entity should have belt geometry drawn over it
     * (all living player-like entities that are alive and not the
     * spectating camera's own invisible state).
     */
    public boolean shouldRenderFor(Entity entity, Entity cameraEntity) {
        if (!(entity instanceof LivingEntity living)) {
            return false;
        }
        if (!living.isAlive()) {
            return false;
        }
        return true;
    }
}