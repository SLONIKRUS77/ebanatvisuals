package net.fabricmc.example.render;

import net.fabricmc.example.config.ModuleManager;
import net.fabricmc.example.config.Theme;
import net.fabricmc.example.gui.GuiRenderUtil;
import net.fabricmc.example.modules.InfoHUDModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.text.Text;

import java.util.Collection;

/**
 * Renders the rounded, semi-transparent Info HUD panel showing the
 * player's username, server IP (or "Singleplayer"), ping in ms, and the
 * current online player count. Position is fully responsive: it is
 * recomputed every frame from the current scaled window dimensions so
 * it stays correctly anchored across resolution changes (including
 * PojavLauncher's dynamic mobile screen sizes).
 */
public class InfoHUD {

    private static final int MARGIN = 8;
    private static final int PADDING = 8;
    private static final int LINE_HEIGHT = 11;

    private final ModuleManager moduleManager;

    public InfoHUD(ModuleManager moduleManager) {
        this.moduleManager = moduleManager;
    }

    public void render(DrawContext context, RenderTickCounter tickCounter) {
        InfoHUDModule module = moduleManager.getInfoHUDModule();
        if (!module.isEnabled()) {
            return;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            return;
        }

        float scale = module.scaleSetting().getValue();
        int panelAlpha = module.panelAlphaSetting().getIntValue();

        String username = client.player.getGameProfile().getName();
        String serverLabel = resolveServerLabel(client);
        int ping = resolvePing(client);
        int playerCount = resolvePlayerCount(client);

        String line1 = "Player: " + username;
        String line2 = "Server: " + serverLabel;
        String line3 = "Ping: " + ping + " ms";
        String line4 = "Players: " + playerCount;

        int textWidth = Math.max(
                Math.max(client.textRenderer.getWidth(line1), client.textRenderer.getWidth(line2)),
                Math.max(client.textRenderer.getWidth(line3), client.textRenderer.getWidth(line4))
        );
        int titleWidth = client.textRenderer.getWidth("ebanatvisuals");
        textWidth = Math.max(textWidth, titleWidth);

        int panelWidth = Math.round((textWidth + PADDING * 2) * scale);
        int panelHeight = Math.round((PADDING * 2 + LINE_HEIGHT * 5) * scale);

        int screenWidth = client.getWindow().getScaledWidth();
        int screenHeight = client.getWindow().getScaledHeight();

        int[] pos = resolvePanelPosition(module.positionSetting().getSelected(), screenWidth, screenHeight, panelWidth, panelHeight);
        int x = pos[0];
        int y = pos[1];

        Theme theme = Theme.get();
        int backgroundColor = (panelAlpha << 24) | (theme.getPanelBackground() & 0x00FFFFFF);
        int accentColor = theme.getAccentARGB(255);
        int radius = theme.getCornerRadius();

        context.getMatrices().push();
        context.getMatrices().translate(x, y, 0);
        context.getMatrices().scale(scale, scale, 1f);

        GuiRenderUtil.drawRoundedRect(context, 0, 0, panelWidth / Math.max(scale, 0.001f), panelHeight / Math.max(scale, 0.001f), radius, backgroundColor);
        GuiRenderUtil.drawRoundedRectBorder(context, 0, 0, panelWidth / Math.max(scale, 0.001f), panelHeight / Math.max(scale, 0.001f), radius, accentColor, 1f);

        int textX = PADDING;
        int textY = PADDING;

        context.drawText(client.textRenderer, Text.literal("ebanatvisuals"), textX, textY, accentColor, false);
        textY += LINE_HEIGHT + 2;
        context.drawText(client.textRenderer, Text.literal(line1), textX, textY, 0xFFFFFFFF, false);
        textY += LINE_HEIGHT;
        context.drawText(client.textRenderer, Text.literal(line2), textX, textY, 0xFFFFFFFF, false);
        textY += LINE_HEIGHT;
        context.drawText(client.textRenderer, Text.literal(line3), textX, textY, 0xFFFFFFFF, false);
        textY += LINE_HEIGHT;
        context.drawText(client.textRenderer, Text.literal(line4), textX, textY, 0xFFFFFFFF, false);

        context.getMatrices().pop();
    }

    private String resolveServerLabel(MinecraftClient client) {
        if (client.isInSingleplayer()) {
            return "Singleplayer";
        }
        if (client.getCurrentServerEntry() != null) {
            return client.getCurrentServerEntry().address;
        }
        return "Unknown";
    }

    private int resolvePing(MinecraftClient client) {
        if (client.player == null || client.getNetworkHandler() == null) {
            return 0;
        }
        PlayerListEntry entry = client.getNetworkHandler().getPlayerListEntry(client.player.getUuid());
        return entry != null ? entry.getLatency() : 0;
    }

    private int resolvePlayerCount(MinecraftClient client) {
        if (client.getNetworkHandler() == null) {
            return client.isInSingleplayer() ? 1 : 0;
        }
        Collection<PlayerListEntry> entries = client.getNetworkHandler().getPlayerList();
        return entries != null ? entries.size() : 0;
    }

    /**
     * Computes the top-left pixel anchor for the panel given a logical
     * position enum value and the current scaled screen dimensions,
     * ensuring the panel is always fully on-screen regardless of
     * resolution (desktop or mobile via PojavLauncher).
     */
    private int[] resolvePanelPosition(String position, int screenWidth, int screenHeight, int panelWidth, int panelHeight) {
        int x;
        int y;

        switch (position) {
            case InfoHUDModule.POS_TOP_LEFT -> {
                x = MARGIN;
                y = MARGIN;
            }
            case InfoHUDModule.POS_TOP_CENTER -> {
                x = (screenWidth - panelWidth) / 2;
                y = MARGIN;
            }
            case InfoHUDModule.POS_TOP_RIGHT -> {
                x = screenWidth - panelWidth - MARGIN;
                y = MARGIN;
            }
            case InfoHUDModule.POS_BOTTOM_LEFT -> {
                x = MARGIN;
                y = screenHeight - panelHeight - MARGIN;
            }
            case InfoHUDModule.POS_BOTTOM_RIGHT -> {
                x = screenWidth - panelWidth - MARGIN;
                y = screenHeight - panelHeight - MARGIN;
            }
            default -> {
                x = MARGIN;
                y = MARGIN;
            }
        }

        x = Math.max(0, Math.min(x, screenWidth - panelWidth));
        y = Math.max(0, Math.min(y, screenHeight - panelHeight));

        return new int[]{x, y};
    }
}