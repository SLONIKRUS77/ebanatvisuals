package net.fabricmc.example.render;

import net.fabricmc.example.config.ColorSetting;
import net.fabricmc.example.config.ModuleManager;
import net.fabricmc.example.modules.HitParticlesModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.entity.Entity;
import net.minecraft.particle.DustParticleEffect;
import org.joml.Vector3f;

import java.util.Random;

/**
 * Spawns the custom hit-particle burst configured by the Hit Particles
 * module whenever the local player attacks an entity. Triggered from
 * {@link net.fabricmc.example.mixin.ClientPlayerEntityMixin}'s attack hook.
 * Uses vanilla's DUST particle type since it natively accepts an RGB
 * color and scale, giving full color-picker control without any custom
 * particle texture/registration.
 */
public class HitParticlesEngine {

    private final ModuleManager moduleManager;
    private final Random random = new Random();

    public HitParticlesEngine(ModuleManager moduleManager) {
        this.moduleManager = moduleManager;
    }

    /**
     * Called from the attack-entity mixin injection point with the
     * entity that was just hit.
     */
    public void spawnHitParticles(Entity target) {
        HitParticlesModule module = moduleManager.getHitParticlesModule();
        if (!module.isEnabled()) {
            return;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null || client.particleManager == null) {
            return;
        }

        ColorSetting color = module.colorSetting();
        int amount = module.amountSetting().getIntValue();
        float spreadSpeed = module.spreadSpeedSetting().getValue();

        float[] rgb = color.toFloatArray();
        Vector3f colorVec = new Vector3f(rgb[0], rgb[1], rgb[2]);
        DustParticleEffect effect = new DustParticleEffect(colorVec, 1.2f);

        double originX = target.getX();
        double originY = target.getY() + target.getHeight() * 0.5;
        double originZ = target.getZ();

        ParticleManager particleManager = client.particleManager;

        for (int i = 0; i < amount; i++) {
            double offsetX = (random.nextDouble() - 0.5) * target.getWidth();
            double offsetY = (random.nextDouble() - 0.5) * target.getHeight() * 0.5;
            double offsetZ = (random.nextDouble() - 0.5) * target.getWidth();

            double velX = (random.nextDouble() - 0.5) * spreadSpeed;
            double velY = random.nextDouble() * spreadSpeed;
            double velZ = (random.nextDouble() - 0.5) * spreadSpeed;

            particleManager.addParticle(
                    effect,
                    originX + offsetX,
                    originY + offsetY,
                    originZ + offsetZ,
                    velX, velY, velZ
            );
        }
    }
}