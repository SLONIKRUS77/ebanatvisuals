package net.fabricmc.example;

import net.fabricmc.example.config.ModuleManager;
import net.fabricmc.example.gui.ClickGUI;
import net.fabricmc.example.render.BeltRenderEngine;
import net.fabricmc.example.render.HitParticlesEngine;
import net.fabricmc.example.render.InfoHUD;
import net.fabricmc.example.render.WorldColorEngine;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

/**
 * Client-only entrypoint. Registered via the "client" entrypoint key in
 * fabric.mod.json. Owns the singleton instances of every render engine,
 * the module manager, and the ClickGUI screen, and wires up the keybind
 * that toggles the GUI (default: RIGHT SHIFT).
 */
public class EbanatVisualsClient implements ClientModInitializer {

    public static KeyBinding openGuiKey;
    public static ClickGUI clickGUI;

    public static ModuleManager moduleManager;
    public static WorldColorEngine worldColorEngine;
    public static InfoHUD infoHUD;
    public static HitParticlesEngine hitParticlesEngine;
    public static BeltRenderEngine beltRenderEngine;

    @Override
    public void onInitializeClient() {
        moduleManager = new ModuleManager();
        moduleManager.registerDefaultModules();

        worldColorEngine = new WorldColorEngine(moduleManager);
        infoHUD = new InfoHUD(moduleManager);
        hitParticlesEngine = new HitParticlesEngine(moduleManager);
        beltRenderEngine = new BeltRenderEngine(moduleManager);

        clickGUI = new ClickGUI(moduleManager);

        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.ebanatvisuals.open_gui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.ebanatvisuals.general"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(this::onClientTick);

        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player == null || client.world == null) {
                return;
            }
            infoHUD.render(drawContext, tickCounter);
        });

        EbanatVisualsMod.LOGGER.info("[{}] Client initialization complete.", EbanatVisualsMod.MOD_NAME);
    }

    private void onClientTick(MinecraftClient client) {
        while (openGuiKey.wasPressed()) {
            toggleGui(client);
        }
        worldColorEngine.tick();
    }

    private static void toggleGui(MinecraftClient client) {
        if (client.currentScreen instanceof ClickGUI) {
            client.setScreen(null);
        } else if (client.currentScreen == null) {
            client.setScreen(clickGUI);
        }
    }
}